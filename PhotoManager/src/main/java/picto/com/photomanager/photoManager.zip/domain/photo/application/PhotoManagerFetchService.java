package picto.com.photomanager.domain.photo.application;

public class PhotoManagerFetchService {
}
