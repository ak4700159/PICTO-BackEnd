package picto.com.photomanager.domain.photo.dto;

public class AddPhotoRequest {
}
