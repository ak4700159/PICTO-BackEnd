package picto.com.photomanager.domain.photo.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;

@Getter
@Setter
@Embeddable
@NoArgsConstructor
@EqualsAndHashCode
public class PhotoId implements Serializable {
    @Column(name = "photo_id")
    private int photo_id;

    @Column(name = "user_id", nullable = false)
    private int user_id;

    public PhotoId(int photo_id, int user_id) {
        this.photo_id = photo_id;
        this.user_id = user_id;
    }

}
